package com.example.guppyfishfarm_10.repository

import com.example.guppyfishfarm_10.dao.FarmDao
import com.example.guppyfishfarm_10.model.Farm
import kotlinx.coroutines.flow.Flow

class FarmRepository (private val farmDao: FarmDao) {
    val allFarms: Flow<List<Farm>> = farmDao.getAllFarm()

    suspend fun insertFarm(farm: Farm) {
        farmDao.insertFarm(farm)
    }

    suspend fun deleteFarm(farm: Farm) {
        farmDao.deleteFarm(farm)
    }


    suspend fun updateFarm(farm: Farm) {
        farmDao.updateFarm(farm)
    }
}