package com.example.guppyfishfarm_10.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.guppyfishfarm_10.model.Farm
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmDao {
    @Query("SELECT * FROM farm_table ORDER BY name ASC")
    fun getAllFarm(): Flow<List<Farm>>

    @Insert
    suspend fun insertFarm(farm: Farm)

    @Delete
    suspend fun deleteFarm(farm: Farm)

    @Update fun updateFarm(farm: Farm)
}