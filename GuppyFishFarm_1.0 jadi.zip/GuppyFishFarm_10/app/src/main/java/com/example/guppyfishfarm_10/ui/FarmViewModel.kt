package com.example.guppyfishfarm_10.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.guppyfishfarm_10.model.Farm
import com.example.guppyfishfarm_10.repository.FarmRepository
import kotlinx.coroutines.launch

class FarmViewModel(private val repository: FarmRepository): ViewModel() {
    val allFarms: LiveData<List<Farm>> = repository.allFarms.asLiveData()

    fun insert(farm: Farm) = viewModelScope.launch {
        repository.insertFarm(farm)
    }

    fun delete(farm: Farm) = viewModelScope.launch {
        repository.deleteFarm(farm)
    }

    fun update(farm: Farm) = viewModelScope.launch {
        repository.updateFarm(farm)
    }
}

class FarmViewModelFactory(private val repository: FarmRepository): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom((FarmViewModel::class.java))) {
            return FarmViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}