package com.example.guppyfishfarm_10.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.guppyfishfarm_10.LoginActivity
import com.example.guppyfishfarm_10.Preferences
import com.example.guppyfishfarm_10.R
import com.example.guppyfishfarm_10.application.FarmApp
import com.example.guppyfishfarm_10.databinding.FragmentFirstBinding

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    private val binding get() = _binding!!
    private lateinit var applicationContext: Context
    private val farmViewModel: FarmViewModel by viewModels {
        FarmViewModelFactory((applicationContext as FarmApp).repository)
    }
    private lateinit var preferences: Preferences
    private lateinit var intent: Intent

    override fun onAttach(context: Context) {
        super.onAttach(context)
        applicationContext = requireContext().applicationContext
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        preferences = Preferences(requireContext())

        val adapter = FarmListAdapter { farm ->
            val action = FirstFragmentDirections.actionFirstFragmentToSecondFragment(farm)
            findNavController().navigate(action)
        }

        binding.dataRecyclerView.adapter = adapter
        binding.dataRecyclerView.layoutManager = LinearLayoutManager(context)
        farmViewModel.allFarms.observe(viewLifecycleOwner) {farms ->
            farms.let {
                if (farms.isEmpty()) {
                    binding.errorTextView.visibility = View.VISIBLE
                    binding.illustrationImageView.visibility = View.VISIBLE
                } else {
                    binding.errorTextView.visibility = View.GONE
                    binding.illustrationImageView.visibility = View.GONE
                }
                adapter.submitList(farms)
            }
        }

        binding.addBut.setOnClickListener {
            val action = FirstFragmentDirections.actionFirstFragmentToSecondFragment(null)
            findNavController().navigate(action)
        }

        binding.logoutButton.setOnClickListener {
            preferences.isLoggedIn = false
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}