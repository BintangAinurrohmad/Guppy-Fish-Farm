package com.example.guppyfishfarm_10.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView.OnItemClickListener
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.guppyfishfarm_10.R
import com.example.guppyfishfarm_10.model.Farm

class FarmListAdapter(
    private val onItemClickListener: (Farm) -> Unit
): ListAdapter<Farm, FarmListAdapter.FarmViewHolder>(WORDS_COMPARATOR) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FarmViewHolder {
       return FarmViewHolder.create(parent)
    }

    override fun onBindViewHolder(holder: FarmViewHolder, position: Int) {
        val farm = getItem(position)
        holder.bind(farm)
        holder.itemView.setOnClickListener {
            onItemClickListener(farm)
        }

    }

    class FarmViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
        private val addressTextView: TextView = itemView.findViewById(R.id.addressTextView)
        private val speciesTextView: TextView = itemView.findViewById(R.id.speciesTextView)

        fun bind(farm: Farm?) {
            nameTextView.text = farm?.name
            addressTextView.text = farm?.address
            speciesTextView.text = farm?.species
        }

        companion object {
            fun create(parent: ViewGroup): FarmListAdapter.FarmViewHolder {
                val view: View = LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_farm, parent, false)
                return FarmViewHolder(view)
            }
        }
    }

    companion object {
        private val WORDS_COMPARATOR = object : DiffUtil.ItemCallback<Farm>() {
            override fun areItemsTheSame(oldItem: Farm, newItem: Farm): Boolean {
               return oldItem == newItem
            }

            override fun areContentsTheSame(oldItem: Farm, newItem: Farm): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }
}