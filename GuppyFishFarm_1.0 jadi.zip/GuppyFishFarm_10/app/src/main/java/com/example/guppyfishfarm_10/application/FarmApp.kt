package com.example.guppyfishfarm_10.application

import android.app.Application
import com.example.guppyfishfarm_10.repository.FarmRepository

class FarmApp: Application() {
    val database by lazy { FarmDatabase.getDatabase(this) }
    val repository by lazy { FarmRepository(database.farmDao()) }
}