package com.example.guppyfishfarm_10

import android.content.Context
import android.content.SharedPreferences

class Preferences(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    var isLoggedIn: Boolean
        get() = sharedPreferences.getBoolean("isLoggedIn", false)
        set(value) = sharedPreferences.edit().putBoolean("isLoggedIn", value).apply()

    var email: String?
        get() = sharedPreferences.getString("email", null)
        set(value) = sharedPreferences.edit().putString("email", value).apply()

    var password: String?
        get() = sharedPreferences.getString("password", null)
        set(value) = sharedPreferences.edit().putString("password", value).apply()
}